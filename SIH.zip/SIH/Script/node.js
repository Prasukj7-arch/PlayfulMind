mkdir server
cd server
npm init -y
npm install express socket.io
