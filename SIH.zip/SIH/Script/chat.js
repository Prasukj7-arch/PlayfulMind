// Client-side chat.js

// Connect to the server using Socket.IO
const socket = io();

// Event listener for send button
document.getElementById('send-button').addEventListener('click', () => {
  const messageInput = document.getElementById('message-input');
  const message = messageInput.value;

  // Emit the message to the server
  socket.emit('chatMessage', message);

  // Clear the input field
  messageInput.value = '';
});

// Listen for chatMessage event from server
socket.on('chatMessage', (msg) => {
  const chatBox = document.getElementById('chat-box');
  const messageElement = document.createElement('p');
  messageElement.textContent = msg;
  chatBox.appendChild(messageElement);
  chatBox.scrollTop = chatBox.scrollHeight; // Scroll to the bottom of the chat box
});
